'''  Name: George Liu
     Email: george.liu@slu.edu
     Current Date: 2/16/18
     Course Information: CSCI 1300 Object Oriented Programming
     Instructor: Judy Etchison
Honor Code Statement: In keeping with the honor code policies of
St. Louis University, the Department of Mathematics and Computer
Science, I affirm that I have neither given nor received assistance
on this programming assignment. This assignment represents my
individual, original effort. 
'''


from cs1graphics import *

colors=list() #list of colors
checkerboards=int(raw_input('Enter the amount of checkboards you want displayed(up to six)'))
while(1==1):
    color=raw_input('Enter a color. Enter the same amount of colors as checkboards. Enter quit once you are done')
    if color=='quit':
        break
    colors.append(color)
rows=int(raw_input('Enter the amount of rows you want each board to be.'))
columns=int(raw_input('Enter the amount of columns you want each board to be.'))
nColumns=columns #capturing the number of columns
whiteSpace=False #Boolean for switching colors for checkerboard
xValue=0
yValue=0
yStart=20
checkThree=0 #Check to see when to make a new row of 3

#main
myCanvas=Canvas(1500,500)
for i in range(checkerboards): #makes another board
    for j in range(rows): #makes another row
        for k in range(columns): #makes a column
            square=Rectangle(20,20,Point(20+xValue,yStart+yValue))
            if whiteSpace==True:
                square.setFillColor('white')
                whiteSpace=False
            else: 
                square.setFillColor(colors[i])
                whiteSpace=True
            myCanvas.add(square)
            xValue=xValue+20
        if nColumns%2==0 and whiteSpace==True: #accounts for even numbered rows
            whiteSpace=False
        elif nColumns%2==0 and whiteSpace==False: #accounts for even numbered rows
            whiteSpace=True
        xValue=xValue-20*columns #sets new xValue for new row
        yValue=yValue+20 #sets new yValue for new row
    xValue=20*columns+checkThree*columns*20 #sets new xValue for new board
    yValue=0 #sets new yValue for new board
    checkThree=checkThree+1 #checks if three boards are down
    if checkThree%3==0: # makes a new row of boards
        xValue=0
        yStart=20+20*rows*(checkThree/3)
        checkThree=0
        
        
    
   
