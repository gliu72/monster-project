class MyData:
    def __init__ (self):
        self._friend = [] 
    def readFile(self, filename):
        Data = file(filename)
        line = Data.readline()
        while line:
            data = line.split('/')
            friend1 = [data[0],data[1],data[2]]
            self._friend.append(friend1)       
            line = Data.readline()
        Data.close()
    def display (self):
        for object in self._friend:
            print 'name:' + object[0]
            print 'address' + object[1]
            print 'phonenumber' + object[2]

        
Data = MyData()
Data.readFile('friends.txt')
Data.display()
