aList=list()
for i in range(9):
    aList.append(0)
aList[4]='hi'
print aList
aSet=set()
aSet.add('hello')
print aSet
aSet=set()
print aSet
print aList[4]
if 'hi' in aList:
    print True
x=print 'hi'
